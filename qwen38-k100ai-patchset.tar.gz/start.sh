#!/usr/bin/env bash
set -euo pipefail
TARGET_ROOT=/data/qwen38-27b-k100ai-int8-opt
DFLASH_ROOT=/data/qwen38-dflash2-k100ai
MODEL=${MODEL:-/models/target}
DRAFT_MODEL=${DRAFT_MODEL:-/models/draft}
PORT=${PORT:-8068}
TP_SIZE=${TP_SIZE:-4}

for p in "$MODEL/config.json" "$DRAFT_MODEL/config.json" "$DRAFT_MODEL/model.safetensors"; do
  [[ -f "$p" ]] || { echo "ERROR: missing $p" >&2; exit 20; }
done

export PYTHONPATH="$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1${PYTHONPATH:+:$PYTHONPATH}"
export HSA_FORCE_FINE_GRAIN_PCIE=${HSA_FORCE_FINE_GRAIN_PCIE:-1}
export W8A8_SUPPORT_METHODS=${W8A8_SUPPORT_METHODS:-1}
export SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN=1
export SGLANG_KV_LAYOUT_DCU_FA=true
export SGLANG_USE_LIGHTOP=0
export SGLANG_USE_CAUSAL_CONV1D=0
export SGLANG_USE_TRITON_VLLM_FA=0
export SGLANG_Q38_COMPACT_HEAD_M1=0
export SGLANG_Q38_TP4_COMPACT_HEAD_M1=1
export SGLANG_Q38_TP4_ROW_LDSX_M1=1
export SGLANG_Q38_TP4_ROW_LDSX_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_tp4_row_ldsx_v1_sglang.so"
export SGLANG_Q38_TP4_K5120_LDSX_M1=1
export SGLANG_Q38_TP4_U036_KV_LENGTHS=${SGLANG_Q38_TP4_U036_KV_LENGTHS:-16384,24576,32768,40960,49152,57344,65536,73728,81920,90112,98304,106496,114688,122880,131072,139264,147456,155648,163840,172032,180224,188416,196608,204800,212992,221184,229376,237568,245760,253952}
export SGLANG_Q38_TP4_U036_BLOCK_M=${SGLANG_Q38_TP4_U036_BLOCK_M:-64}
# Full 10-level authority defaults. Opt in to latest 64K/128K profile with:
#   SGLANG_Q38_TP4_U036_PROFILE=ranklocal_bm64_w4_preloadv
#   SGLANG_Q38_TP4_U036_SPLIT_KV=4
export SGLANG_Q38_TP4_U036_PROFILE=${SGLANG_Q38_TP4_U036_PROFILE:-legacy_bm64_w8}
export SGLANG_Q38_TP4_U036_SPLIT_KV=${SGLANG_Q38_TP4_U036_SPLIT_KV:-1}
export SGLANG_Q38_GDN_BA_FUSED_M1=1
export SGLANG_Q38_SWIGLU_INT8_M1=1
export SGLANG_USE_FUSED_SILU_MUL_QUANT=1
export SGLANG_Q38_RMS_GDN_INT8_M1=1
export SGLANG_Q38_TP4_RMS_QKVZ_M1=1
export SGLANG_Q38_TP4_BA24_INT8_M1=1
export SGLANG_Q38_NATIVE_OUT_GEMV_M1=1
export SGLANG_Q38_NATIVE_OUT_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_v7_sglang.so"
export SGLANG_Q38_NATIVE_BODY_GEMV_M1=1
export SGLANG_Q38_NATIVE_BODY_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_generic_v2_sglang.so"
export SGLANG_Q38_NATIVE_BODY_GEMV_FAMILIES=gate_up,full_qkv
export SGLANG_Q38_NATIVE_GDN_SPLIT_M1=1
export SGLANG_Q38_NATIVE_GDN_SPLIT_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_generic_v2_sglang.so"
export SGLANG_Q38_DEEP_DOWN_GEMV_M1=1
export SGLANG_Q38_DEEP_DOWN_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_deep_v4_sglang.so"
export SGLANG_DFLASH2_DEBUG_STATS=${SGLANG_DFLASH2_DEBUG_STATS:-0}
export SGLANG_DFLASH2_STAGE_SYNC=${SGLANG_DFLASH2_STAGE_SYNC:-0}

exec python3 -u "$TARGET_ROOT/scripts/launch_sglang_require_sitecustomize.py" \
  --model-path "$MODEL" \
  --host 0.0.0.0 --port "$PORT" --random-seed 0 \
  --served-model-name Qwen3.8-27B-W8A8-DFlash2-TP4-Agent128K \
  --chat-template "$DFLASH_ROOT/runtime_assets/qwen38_chat_template.jinja" \
  --dtype bfloat16 --kv-cache-dtype bfloat16 \
  --tp-size "$TP_SIZE" --pp-size 1 \
  --attention-backend fa3 --mm-attention-backend fa3 \
  --page-size 64 --mamba-scheduler-strategy extra_buffer --max-mamba-cache-size 16 \
  --cuda-graph-bs 1 --disable-piecewise-cuda-graph --disable-custom-all-reduce \
  --context-length ${CONTEXT_LENGTH:-262144} \
  --mem-fraction-static ${MEM_FRACTION_STATIC:-0.90} \
  --chunked-prefill-size ${CHUNKED_PREFILL_SIZE:-8192} \
  --max-prefill-tokens ${MAX_PREFILL_TOKENS:-16384} \
  --pack-paged-kv-to-varlen auto \
  --pack-paged-kv-to-varlen-min-q-tokens ${PACK_MIN_Q:-2048} \
  --pack-paged-kv-to-varlen-min-kv-tokens ${PACK_MIN_KV:-8192} \
  --max-total-tokens ${MAX_TOTAL_TOKENS:-1048576} \
  --max-running-requests ${MAX_RUNNING_REQUESTS:-4} \
  --speculative-algorithm DFLASH \
  --speculative-draft-model-path "$DRAFT_MODEL" \
  --speculative-draft-model-quantization unquant \
  --speculative-draft-attention-backend triton \
  --speculative-num-steps 1 --speculative-num-draft-tokens 8 \
  --enable-metrics --tool-call-parser qwen3_coder --reasoning-parser qwen3
