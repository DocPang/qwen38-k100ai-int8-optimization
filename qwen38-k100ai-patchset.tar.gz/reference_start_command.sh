#!/usr/bin/env bash
set -euo pipefail

# Long-lived Agent deployment: Qwen3.8-27B W8A8 target + DFlash2, TP4 on GPU4-7.
# Primary tuning anchor: 128K context. Radix/KV prefix cache stays ENABLED.

ROOT=${ROOT:-/data/qwen38-dflash2-k100ai}
TARGET_ROOT=${TARGET_ROOT:-/data/qwen38-27b-k100ai-int8-opt}
IMAGE=${IMAGE:-harbor.sourcefind.cn:5443/dcu/admin/base/custom:sglang0.5.12-ubuntu22.04-dtk26.04-py3.10-20260620}
MODEL=${MODEL:-/data/my_models/Qwen/Qwen3.8-27B-SmoothQuant-W8A8-INT8}
DRAFT=${DRAFT:-$ROOT/models/Qwen3.8-27B-DFlash2}
OVERLAY=${OVERLAY:-$ROOT/work/sourcefind_sglang_overlay_tp4/python}
PATCH=${PATCH:-$ROOT/runtime_patch_dflash_tp4_agent128k_v1}
NAME=${NAME:-q38-dflash2-tp4-agent128k-gpu4567}
PORT=${PORT:-8068}

# Agent-oriented defaults. 0.90 leaves more runtime/JIT headroom than a 0.95
# benchmark-only layout while still reserving a large KV pool on each K100AI.
MEM_FRACTION_STATIC=${MEM_FRACTION_STATIC:-0.90}
CONTEXT_LENGTH=${CONTEXT_LENGTH:-262144}
CHUNKED_PREFILL_SIZE=${CHUNKED_PREFILL_SIZE:-8192}
MAX_PREFILL_TOKENS=${MAX_PREFILL_TOKENS:-16384}
MAX_RUNNING_REQUESTS=${MAX_RUNNING_REQUESTS:-4}
MAX_TOTAL_TOKENS=${MAX_TOTAL_TOKENS:-}
MAX_MAMBA_CACHE_SIZE=${MAX_MAMBA_CACHE_SIZE:-16}
PACK_MIN_Q=${PACK_MIN_Q:-2048}
PACK_MIN_KV=${PACK_MIN_KV:-8192}
U036_BLOCK_M=${U036_BLOCK_M:-64}
U036_PROFILE=${U036_PROFILE:-legacy_bm64_w8}
CUDA_GRAPH=${CUDA_GRAPH:-1}
CUSTOM_AR=${CUSTOM_AR:-0}
DEBUG_STATS=${DEBUG_STATS:-0}
STAGE_SYNC=${STAGE_SYNC:-0}

CHAT_TEMPLATE=${CHAT_TEMPLATE:-$ROOT/runtime_assets/qwen38_chat_template.jinja}
TRITON_JSON_DIR=${TRITON_JSON_DIR:-$TARGET_ROOT/cache/sglang_w8a8_gfx928_tp4_gpu4567_v1}
TORCH_EXT_CACHE=${TORCH_EXT_CACHE:-$ROOT/cache/torch_extensions_tp4_agent128k_gpu4567}
TORCHINDUCTOR_CACHE_DIR=${TORCHINDUCTOR_CACHE_DIR:-$ROOT/cache/torchinductor_tp4_agent128k_gpu4567}
TRITON_CACHE_DIR=${TRITON_CACHE_DIR:-$ROOT/cache/triton_tp4_agent128k_gpu4567}

for p in "$MODEL" "$DRAFT" "$OVERLAY" "$PATCH/sitecustomize.py" "$CHAT_TEMPLATE"; do
  [[ -e "$p" ]] || { echo "ERROR: missing required path: $p" >&2; exit 80; }
done

RENDERS=(/dev/dri/renderD132 /dev/dri/renderD133 /dev/dri/renderD134 /dev/dri/renderD135)
for r in "${RENDERS[@]}"; do [[ -e "$r" ]] || { echo "ERROR: missing $r" >&2; exit 81; }; done

docker inspect "$NAME" >/dev/null 2>&1 && { echo "ERROR: container exists: $NAME" >&2; exit 82; }
ss -ltnH | awk '{print $4}' | grep -Eq "(^|:)${PORT}$" && { echo "ERROR: port ${PORT} occupied" >&2; exit 83; }

# Fail closed: do not steal GPU4-7 from another workload.
for g in 4 5 6 7; do
  out=$(/usr/local/hyhal/bin/hy-smi -d "$g" --showuse --showmemuse 2>/dev/null || true)
  printf '%s\n' "$out"
  printf '%s\n' "$out" | grep -q 'HCU use (%): 0.0' || { echo "ERROR: GPU${g} compute busy" >&2; exit 84; }
  printf '%s\n' "$out" | grep -q 'HCU memory use (%): 0' || { echo "ERROR: GPU${g} memory busy" >&2; exit 85; }
done
exec 9>/tmp/qwen38_gpu4567_dflash2_tp4_start.lock
flock -n 9 || { echo "ERROR: GPU4-7 DFlash2 TP4 start lock busy" >&2; exit 86; }

mkdir -p "$TORCH_EXT_CACHE" "$TORCHINDUCTOR_CACHE_DIR" "$TRITON_CACHE_DIR" "$ROOT/logs"

graph_args=(--disable-cuda-graph --disable-piecewise-cuda-graph)
if [[ "$CUDA_GRAPH" == 1 ]]; then
  # Agent workload is predominantly c1; keep only bs1 graph to minimize memory.
  graph_args=(--cuda-graph-bs 1 --disable-piecewise-cuda-graph)
elif [[ "$CUDA_GRAPH" != 0 ]]; then
  echo "ERROR: CUDA_GRAPH must be 0/1" >&2; exit 87
fi

ar_args=(--disable-custom-all-reduce)
if [[ "$CUSTOM_AR" == 1 ]]; then
  ar_args=()
elif [[ "$CUSTOM_AR" != 0 ]]; then
  echo "ERROR: CUSTOM_AR must be 0/1" >&2; exit 89
fi

total_tokens_args=()
if [[ -n "$MAX_TOTAL_TOKENS" ]]; then
  [[ "$MAX_TOTAL_TOKENS" =~ ^[0-9]+$ ]] || { echo "ERROR: MAX_TOTAL_TOKENS must be an integer" >&2; exit 88; }
  total_tokens_args=(--max-total-tokens "$MAX_TOTAL_TOKENS")
fi

# DFlash2 overlay must follow PATCH so the composed sitecustomize is imported,
# while normal sglang modules come from the isolated TP4 overlay.
env_args=(
  -e PYTHONPATH="$PATCH:$OVERLAY"
  -e HIP_VISIBLE_DEVICES=0,1,2,3
  -e HSA_FORCE_FINE_GRAIN_PCIE=1
  -e W8A8_SUPPORT_METHODS=1
  -e SGLANG_ALLOW_OVERWRITE_LONGER_CONTEXT_LEN=1
  -e SGLANG_KV_LAYOUT_DCU_FA=true
  -e SGLANG_USE_LIGHTOP=0
  -e SGLANG_USE_CAUSAL_CONV1D=0
  -e SGLANG_USE_TRITON_VLLM_FA=0
  -e TRITON_JSON_DIR="$TRITON_JSON_DIR"
  -e TORCHINDUCTOR_CACHE_DIR="$TORCHINDUCTOR_CACHE_DIR"
  -e TRITON_CACHE_DIR="$TRITON_CACHE_DIR"
  -e SGLANG_Q38_COMPACT_HEAD_M1=0
  -e SGLANG_Q38_TP4_COMPACT_HEAD_M1=1
  -e SGLANG_Q38_TP4_ROW_LDSX_M1=1
  -e SGLANG_Q38_TP4_ROW_LDSX_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_tp4_row_ldsx_v1_sglang.so"
  -e SGLANG_Q38_TP4_K5120_LDSX_M1=1
  -e SGLANG_Q38_TP4_U036_KV_LENGTHS="16384,24576,32768,40960,49152,57344,65536,73728,81920,90112,98304,106496,114688,122880,131072,139264,147456,155648,163840,172032,180224,188416,196608,204800,212992,221184,229376,237568,245760,253952"
  -e SGLANG_Q38_TP4_U036_BLOCK_M="$U036_BLOCK_M"
  -e SGLANG_Q38_TP4_U036_PROFILE="$U036_PROFILE"
  -e SGLANG_Q38_GDN_BA_FUSED_M1=1
  -e SGLANG_Q38_SWIGLU_INT8_M1=1
  -e SGLANG_USE_FUSED_SILU_MUL_QUANT=1
  -e SGLANG_Q38_RMS_GDN_INT8_M1=1
  -e SGLANG_Q38_TP4_RMS_QKVZ_M1=1
  -e SGLANG_Q38_TP4_BA24_INT8_M1=1
  -e SGLANG_Q38_NATIVE_OUT_GEMV_M1=1
  -e SGLANG_Q38_NATIVE_OUT_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_v7_sglang.so"
  -e SGLANG_Q38_NATIVE_BODY_GEMV_M1=1
  -e SGLANG_Q38_NATIVE_BODY_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_generic_v2_sglang.so"
  -e SGLANG_Q38_NATIVE_BODY_GEMV_FAMILIES=gate_up,full_qkv
  -e SGLANG_Q38_NATIVE_GDN_SPLIT_M1=1
  -e SGLANG_Q38_NATIVE_GDN_SPLIT_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_generic_v2_sglang.so"
  -e SGLANG_Q38_DEEP_DOWN_GEMV_M1=1
  -e SGLANG_Q38_DEEP_DOWN_GEMV_SO="$TARGET_ROOT/native_ext/k100_int8_gemv_deep_v4_sglang.so"
  -e SGLANG_DFLASH2_DEBUG_STATS="$DEBUG_STATS"
  -e SGLANG_DFLASH2_STAGE_SYNC="$STAGE_SYNC"
)

cid=$(docker run -d \
  --name "$NAME" \
  --restart unless-stopped \
  --network host \
  --ipc host \
  --security-opt label=disable \
  --label devspace.goal=q38-dflash2-agent128k-tp4-20260821 \
  --label k100.owner=manual-user-dflash2-tp4-gpu4567 \
  --device /dev/kfd \
  --device ${RENDERS[0]} --device ${RENDERS[1]} --device ${RENDERS[2]} --device ${RENDERS[3]} \
  --mount type=bind,src=/data,dst=/data,bind-propagation=rslave \
  --mount type=bind,src=/opt/hyhal,dst=/opt/hyhal,readonly \
  --mount type=bind,src="$TORCH_EXT_CACHE",dst=/root/.cache/torch_extensions \
  --mount type=bind,src="$TARGET_ROOT/runtime_assets/ninja_native_wrapper.sh",dst=/usr/local/bin/ninja,readonly \
  --mount type=bind,src=/data/my_models/Qwen/Qwen3.8-27B/preprocessor_config.json,dst=$MODEL/preprocessor_config.json,readonly \
  --mount type=bind,src=/data/my_models/Qwen/Qwen3.8-27B/video_preprocessor_config.json,dst=$MODEL/video_preprocessor_config.json,readonly \
  "${env_args[@]}" \
  "$IMAGE" \
  python3 -u "$TARGET_ROOT/scripts/launch_sglang_require_sitecustomize.py" \
    --model-path "$MODEL" \
    --host 0.0.0.0 \
    --port "$PORT" \
    --random-seed 0 \
    --served-model-name Qwen3.8-27B-W8A8-DFlash2-TP4-Agent128K \
    --chat-template "$CHAT_TEMPLATE" \
    --dtype bfloat16 \
    --kv-cache-dtype bfloat16 \
    --tp-size 4 \
    --pp-size 1 \
    --attention-backend fa3 \
    --mm-attention-backend fa3 \
    --page-size 64 \
    --mamba-scheduler-strategy extra_buffer \
    --max-mamba-cache-size "$MAX_MAMBA_CACHE_SIZE" \
    "${graph_args[@]}" \
    "${ar_args[@]}" \
    --context-length "$CONTEXT_LENGTH" \
    --mem-fraction-static "$MEM_FRACTION_STATIC" \
    --chunked-prefill-size "$CHUNKED_PREFILL_SIZE" \
    --max-prefill-tokens "$MAX_PREFILL_TOKENS" \
    --pack-paged-kv-to-varlen auto \
    --pack-paged-kv-to-varlen-min-q-tokens "$PACK_MIN_Q" \
    --pack-paged-kv-to-varlen-min-kv-tokens "$PACK_MIN_KV" \
    "${total_tokens_args[@]}" \
    --max-running-requests "$MAX_RUNNING_REQUESTS" \
    --speculative-algorithm DFLASH \
    --speculative-draft-model-path "$DRAFT" \
    --speculative-draft-model-quantization unquant \
    --speculative-draft-attention-backend triton \
    --speculative-num-steps 1 \
    --speculative-num-draft-tokens 8 \
    --enable-metrics \
    --tool-call-parser qwen3_coder \
    --reasoning-parser qwen3)

echo "Started $cid"
echo "container=$NAME port=$PORT TP4 GPU4-7 context=$CONTEXT_LENGTH mem_fraction=$MEM_FRACTION_STATIC radix_cache=enabled max_running=$MAX_RUNNING_REQUESTS custom_ar=$CUSTOM_AR u036_profile=$U036_PROFILE"
