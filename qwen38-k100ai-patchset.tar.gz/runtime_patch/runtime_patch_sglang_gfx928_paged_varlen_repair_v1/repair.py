"""Shared gfx928 SGLang paged-varlen correctness repair.

Apply after a TP-specific parent sitecustomize stack.  Keep SourceFind's native
qLen=1 with-kvcache/decode path, but replace the broken multi-token vLLM-style
paged varlen consumer with the stride-aware Triton implementation.

The global SGLANG_USE_TRITON_VLLM_FA switch must remain disabled because that
switch also replaces the native decode consumer and destroys the performance
property this selective repair is designed to preserve.
"""
from __future__ import annotations

import os

_flag = os.getenv("SGLANG_USE_TRITON_VLLM_FA", "0").strip().lower()
if _flag not in ("", "0", "false", "no", "off"):
    raise RuntimeError(
        "selective gfx928 paged-varlen repair requires "
        "SGLANG_USE_TRITON_VLLM_FA=0; got %r" % (_flag,)
    )

from sglang.srt.layers.attention import flashattention_backend as _fab
from sglang.srt.layers.attention import flashattention_interface as _fai
from sglang.srt.layers.attention.triton_vllm_flash_attn import (
    triton_vllm_flash_attn_varlen_func as _triton_paged_varlen,
)

_seen = False


def _q38_gfx928_triton_paged_varlen_only(
    q,
    k,
    v,
    cu_seqlens_q,
    max_seqlen_q,
    seqused_k,
    max_seqlen_k,
    softmax_scale,
    causal,
    window_size,
    block_table,
    fa_version,
    q_descale,
    k_descale,
    v_descale,
):
    global _seen
    if not _seen:
        _seen = True
        print(
            "[K100 SGLang gfx928 paged repair v1] ACTIVE "
            "paged-varlen=Triton; native with-kvcache/decode preserved",
            flush=True,
        )
    return _triton_paged_varlen(
        q=q,
        k=k,
        v=v,
        cu_seqlens_q=cu_seqlens_q,
        max_seqlen_q=max_seqlen_q,
        seqused_k=seqused_k,
        max_seqlen_k=max_seqlen_k,
        softmax_scale=softmax_scale,
        causal=causal,
        window_size=window_size,
        block_table=block_table,
        fa_version=fa_version,
        q_descale=q_descale,
        k_descale=k_descale,
        v_descale=v_descale,
    )


# flashattention_backend imports the interface function by value, so patch both.
_fai.vllm_flash_attn_varlen_func = _q38_gfx928_triton_paged_varlen_only
_fab.vllm_flash_attn_varlen_func = _q38_gfx928_triton_paged_varlen_only

print(
    "[K100 SGLang gfx928 paged repair v1] installed selective consumer; "
    "global Triton FA switch remains off",
    flush=True,
)
