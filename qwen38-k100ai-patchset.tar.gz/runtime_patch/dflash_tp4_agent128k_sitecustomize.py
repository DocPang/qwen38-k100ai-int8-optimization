"""TP4 Agent/128K production composition: BA24 target + DFlash2 q8 verifier.

The target side inherits the proven corrected TP4 BA24 stack from the main
Qwen3.8 W8A8 project (correct gfx928 prefill consumer, TP4 row/rank-local GEMV,
RMS->QKVZ producer and BA24 decode path).  DFlash2 verification normally emits
q=8; on gfx928 the vendor q>=5 paged-varlen kernel is a no-write path, while
q<=4 is proven correct.  Therefore only exact batch1 causal q=8 verification is
split into two native q=4 calls.  All other shapes retain the BA24 parent's
correct routing.
"""
from __future__ import annotations

import os
import runpy

_ROOT = "/data/qwen38-dflash2-k100ai"
_TARGET_ROOT = "/data/qwen38-27b-k100ai-int8-opt"

runpy.run_path(
    f"{_TARGET_ROOT}/runtime_patch_sglang_tp4_u036_rmsqkvz_ba24_v1/sitecustomize.py",
    run_name="__q38_tp4_ba24_parent_for_dflash2_agent128k__",
)

import torch
from sglang.srt.layers.attention import flashattention_backend as _fab
from sglang.srt.layers.attention import flashattention_interface as _fai

_parent = _fab.vllm_flash_attn_varlen_func
_native = _fai.vllm_flash_attn_varlen_func_interface
_seen = False
_cuq_cache: dict[tuple[int | None, int], torch.Tensor] = {}


def _cuq(device: torch.device, qlen: int) -> torch.Tensor:
    key = (device.index, qlen)
    t = _cuq_cache.get(key)
    if t is None:
        t = torch.tensor([0, qlen], device=device, dtype=torch.int32)
        _cuq_cache[key] = t
    return t


def _native_call(
    *, q, k, v, qlen, seqused_k, max_seqlen_k, softmax_scale, causal,
    window_size, block_table, fa_version, q_descale, k_descale, v_descale,
):
    return _native(
        q=q,
        k=k,
        v=v,
        cu_seqlens_q=_cuq(q.device, qlen),
        max_seqlen_q=qlen,
        seqused_k=seqused_k,
        max_seqlen_k=max_seqlen_k,
        softmax_scale=softmax_scale,
        causal=causal,
        window_size=window_size,
        block_table=block_table,
        fa_version=fa_version,
        q_descale=q_descale,
        k_descale=k_descale,
        v_descale=v_descale,
    )


def _dflash_q8_split_native_else_parent(
    q,
    k,
    v,
    cu_seqlens_q,
    max_seqlen_q,
    seqused_k,
    max_seqlen_k,
    softmax_scale,
    causal,
    window_size,
    block_table,
    fa_version,
    q_descale,
    k_descale,
    v_descale,
):
    global _seen
    qlen = int(max_seqlen_q)
    batch = int(cu_seqlens_q.numel() - 1)
    eligible = (
        qlen == 8
        and int(q.shape[0]) == 8
        and batch == 1
        and int(seqused_k.numel()) == 1
        and bool(causal)
        and window_size == (-1, -1)
        and block_table is not None
    )
    if not eligible:
        return _parent(
            q=q, k=k, v=v,
            cu_seqlens_q=cu_seqlens_q,
            max_seqlen_q=max_seqlen_q,
            seqused_k=seqused_k,
            max_seqlen_k=max_seqlen_k,
            softmax_scale=softmax_scale,
            causal=causal,
            window_size=window_size,
            block_table=block_table,
            fa_version=fa_version,
            q_descale=q_descale,
            k_descale=k_descale,
            v_descale=v_descale,
        )

    if not _seen:
        _seen = True
        print(
            "[K100 DFlash2 TP4 Agent128K] ACTIVE q=8 verifier -> 2x native q=4",
            flush=True,
        )

    # Original q=8 corresponds to absolute positions [K-8, ..., K-1].
    # The first q4 must see K-4 keys; the second q4 sees all K keys.
    seq_k_first = seqused_k - 4
    out0 = _native_call(
        q=q[:4], k=k, v=v, qlen=4,
        seqused_k=seq_k_first,
        max_seqlen_k=max(1, int(max_seqlen_k) - 4),
        softmax_scale=softmax_scale, causal=causal,
        window_size=window_size, block_table=block_table, fa_version=fa_version,
        q_descale=q_descale, k_descale=k_descale, v_descale=v_descale,
    )
    out1 = _native_call(
        q=q[4:], k=k, v=v, qlen=4,
        seqused_k=seqused_k,
        max_seqlen_k=max_seqlen_k,
        softmax_scale=softmax_scale, causal=causal,
        window_size=window_size, block_table=block_table, fa_version=fa_version,
        q_descale=q_descale, k_descale=k_descale, v_descale=v_descale,
    )
    if isinstance(out0, (tuple, list)) or isinstance(out1, (tuple, list)):
        raise RuntimeError("DFlash2 TP4 q8split expected tensor outputs")
    return torch.cat((out0, out1), dim=0)


_fai.vllm_flash_attn_varlen_func = _dflash_q8_split_native_else_parent
_fab.vllm_flash_attn_varlen_func = _dflash_q8_split_native_else_parent
print(
    "[K100 DFlash2 TP4 Agent128K] installed: BA24 target + exact q8split; radix/KV policy is launcher-owned",
    flush=True,
)
