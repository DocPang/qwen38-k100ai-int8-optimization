#!/usr/bin/env bash
set -euo pipefail
PAYLOAD=/opt/qwen38-k100ai
SITE=/usr/local/lib/python3.10/dist-packages
TARGET_ROOT=/data/qwen38-27b-k100ai-int8-opt
DFLASH_ROOT=/data/qwen38-dflash2-k100ai

[[ -d "$SITE/sglang" ]] || { echo "missing base SGLang: $SITE/sglang" >&2; exit 2; }
[[ -f "$SITE/flash_attn/flash_attn_triton_mqa_gqa.py" ]] || { echo "missing vendor Triton GQA source" >&2; exit 3; }

# 1) Patch the SGLang shipped by the pinned SourceFind image.
cd "$SITE"
patch --batch --dry-run -p1 < "$PAYLOAD/sglang_dflash2_k100ai.patch"
patch --batch -p1 < "$PAYLOAD/sglang_dflash2_k100ai.patch"

# 2) Preserve the exact absolute-path contract used by the validated target runtime stack.
mkdir -p "$TARGET_ROOT" "$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1" \
  "$DFLASH_ROOT/runtime_assets" "$TARGET_ROOT/native_ext" "$TARGET_ROOT/scripts" \
  "$TARGET_ROOT/external_images/sglang0.5.12-20260620-src/flash_attn"
cp -a "$PAYLOAD/runtime_patch"/runtime_patch_* "$TARGET_ROOT/"
cp "$PAYLOAD/runtime_patch/dflash_tp4_agent128k_sitecustomize.py" \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1/sitecustomize.py"
cp -a "$PAYLOAD/native_ext/"* "$TARGET_ROOT/native_ext/"
cp "$PAYLOAD/target_runtime/launch_sglang_require_sitecustomize.py" "$TARGET_ROOT/scripts/"
cp "$PAYLOAD/target_runtime/qwen38_chat_template.jinja" "$DFLASH_ROOT/runtime_assets/"
cp "$PAYLOAD/target_runtime/ninja_native_wrapper.sh" /usr/local/bin/ninja
chmod +x /usr/local/bin/ninja "$TARGET_ROOT/scripts/launch_sglang_require_sitecustomize.py"
cp "$SITE/flash_attn/flash_attn_triton_mqa_gqa.py" \
  "$TARGET_ROOT/external_images/sglang0.5.12-20260620-src/flash_attn/flash_attn_triton_mqa_gqa.py"

# 3) Fail at build time if the composed Python stack is syntactically damaged.
python3 -m py_compile \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1/sitecustomize.py" \
  "$TARGET_ROOT/runtime_patch_sglang_tp4_u036_longkv_v1/sitecustomize.py" \
  "$SITE/sglang/srt/models/dflash.py" \
  "$SITE/sglang/srt/speculative/dflash_worker.py" \
  "$SITE/sglang/srt/speculative/dflash_utils.py"
