#!/usr/bin/env bash
set -euo pipefail
PAYLOAD=/opt/qwen38-k100ai
SITE=/usr/local/lib/python3.10/dist-packages
TARGET_ROOT=/data/qwen38-27b-k100ai-int8-opt
DFLASH_ROOT=/data/qwen38-dflash2-k100ai
TP4_CACHE_DST=$TARGET_ROOT/cache/sglang_w8a8_gfx928_tp4_longctx_v8
TP2_CACHE_DST=$TARGET_ROOT/cache/sglang_w8a8_gfx928_tp2_gpu23_rowldsx_v1

[[ -d "$SITE/sglang" ]] || { echo "missing base SGLang: $SITE/sglang" >&2; exit 2; }
[[ -f "$SITE/flash_attn/flash_attn_triton_mqa_gqa.py" ]] || { echo "missing vendor Triton GQA source" >&2; exit 3; }
[[ -d "$PAYLOAD/tune_cache/sglang_w8a8_gfx928_tp4_longctx_v8" ]] || { echo "missing TP4 tune cache" >&2; exit 4; }
[[ -d "$PAYLOAD/tune_cache/sglang_w8a8_gfx928_tp2_gpu23_rowldsx_v1" ]] || { echo "missing TP2 tune cache" >&2; exit 5; }

# 1) Patch the SGLang shipped by the pinned SourceFind image with the DFlash2 backport.
cd "$SITE"
patch --batch --dry-run -p1 < "$PAYLOAD/sglang_dflash2_k100ai.patch"
patch --batch -p1 < "$PAYLOAD/sglang_dflash2_k100ai.patch"

# 2) Preserve the exact absolute-path contracts used by the validated TP1/TP2/TP4 stacks.
mkdir -p "$TARGET_ROOT" "$TARGET_ROOT/native_ext" "$TARGET_ROOT/scripts" \
  "$TARGET_ROOT/external_images/sglang0.5.12-20260620-src/flash_attn" \
  "$DFLASH_ROOT/runtime_assets" \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1" \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_q16k_agent128k_v1" \
  "$DFLASH_ROOT/runtime_patch_dflash_q8split_v1" \
  "$TP4_CACHE_DST" "$TP2_CACHE_DST"

# Most runtime patches live under TARGET_ROOT.
cp -a "$PAYLOAD/runtime_patch"/runtime_patch_* "$TARGET_ROOT/"
# TP1 early-Triton/q8split uses the historical DFLASH_ROOT absolute-path chain.
# Keep a byte-identical copy of that complete parent closure under DFLASH_ROOT;
# the same common patches also remain under TARGET_ROOT for TP2/other profiles.
for d in \
  runtime_patch_dflash_q8split_v1 \
  runtime_patch_sglang_spec_q4_native_v1 \
  runtime_patch_sglang_int8_prod_v1 \
  runtime_patch_sglang_u022_paged_varlen_triton_only \
  runtime_patch_sglang_u022_k5120_ldsx \
  runtime_patch_sglang_u019_k5120_full5 \
  runtime_patch_sglang_u016_deep_down \
  runtime_patch_sglang_u010_native_gdn_split \
  runtime_patch_sglang_u008_native_body_gemv \
  runtime_patch_sglang_u004_native_out_gemv \
  runtime_patch_sglang_n7_rms_gdn_exact \
  runtime_patch_sglang_n6_swiglu_exact \
  runtime_patch_sglang_n5_compact_head_gdnint8 \
  runtime_patch_sglang_n5_compact_head \
  runtime_patch_sglang_n4_sparse_w8a8_cache \
  runtime_patch_sglang_w8a8_compat; do
  rm -rf "$DFLASH_ROOT/$d"
  cp -a "$PAYLOAD/runtime_patch/$d" "$DFLASH_ROOT/$d"
done
# TP4 DFlash composition keeps its historical DFLASH_ROOT paths.
cp "$PAYLOAD/runtime_patch/dflash_tp4_agent128k_sitecustomize.py" \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_agent128k_v1/sitecustomize.py"
cp "$PAYLOAD/runtime_patch/dflash_tp4_q16k_agent128k_sitecustomize.py" \
  "$DFLASH_ROOT/runtime_patch_dflash_tp4_q16k_agent128k_v1/sitecustomize.py"

cp -a "$PAYLOAD/tune_cache/sglang_w8a8_gfx928_tp4_longctx_v8/." "$TP4_CACHE_DST/"
cp -a "$PAYLOAD/tune_cache/sglang_w8a8_gfx928_tp2_gpu23_rowldsx_v1/." "$TP2_CACHE_DST/"
cp "$PAYLOAD/target_runtime/launch_sglang_require_sitecustomize.py" "$TARGET_ROOT/scripts/"
cp "$PAYLOAD/target_runtime/qwen38_chat_template.jinja" "$DFLASH_ROOT/runtime_assets/"
cp "$PAYLOAD/target_runtime/ninja_native_wrapper.sh" /usr/local/bin/ninja
chmod +x /usr/local/bin/ninja "$TARGET_ROOT/scripts/launch_sglang_require_sitecustomize.py"
cp "$SITE/flash_attn/flash_attn_triton_mqa_gqa.py" \
  "$TARGET_ROOT/external_images/sglang0.5.12-20260620-src/flash_attn/flash_attn_triton_mqa_gqa.py"

# Stable public aliases. Public entrypoints never expose research iteration names.
ln -sfn "$TARGET_ROOT/runtime_patch_dflash_tp1_final_v2" "$TARGET_ROOT/runtime_patch_tp1"
ln -sfn "$TARGET_ROOT/runtime_patch_sglang_tp2_dflash2_longkv_bm128_v5" "$TARGET_ROOT/runtime_patch_tp2"
ln -sfn "$DFLASH_ROOT/runtime_patch_dflash_tp4_q16k_agent128k_v1" "$DFLASH_ROOT/runtime_patch_tp4"
ln -sfn "$TP2_CACHE_DST" "$TARGET_ROOT/cache/tp2"
ln -sfn "$TP4_CACHE_DST" "$TARGET_ROOT/cache/tp4"

# 3) Install the unified TP1/TP2/TP4 entrypoint series.
cp "$PAYLOAD/profile_runtime/start.sh" "$PAYLOAD/start.sh"
cp "$PAYLOAD/profile_runtime/entrypoint.tp1.sh" "$PAYLOAD/entrypoint.tp1.sh"
cp "$PAYLOAD/profile_runtime/entrypoint.tp2.sh" "$PAYLOAD/entrypoint.tp2.sh"
cp "$PAYLOAD/profile_runtime/entrypoint.tp4.sh" "$PAYLOAD/entrypoint.tp4.sh"
chmod +x "$PAYLOAD/start.sh" "$PAYLOAD/entrypoint.tp1.sh" "$PAYLOAD/entrypoint.tp2.sh" "$PAYLOAD/entrypoint.tp4.sh"

# 4) Fail closed if packaging dropped a validated tune-cache family.
[[ "$(find "$TP4_CACHE_DST" -maxdepth 1 -type f -name 'W8A8_*_gfx928_120cu.json' | wc -l | tr -d ' ')" == 7 ]] \
  || { echo "expected 7 TP4 tune-cache JSONs" >&2; exit 6; }
[[ "$(find "$TP2_CACHE_DST" -maxdepth 1 -type f -name 'W8A8_*_gfx928_120cu.json' | wc -l | tr -d ' ')" == 7 ]] \
  || { echo "expected 7 TP2 tune-cache JSONs" >&2; exit 7; }

# 5) Syntax/audit gate for the three public profile roots and DFlash2 files.
python3 -m py_compile \
  "$TARGET_ROOT/runtime_patch_tp1/sitecustomize.py" \
  "$TARGET_ROOT/runtime_patch_tp2/sitecustomize.py" \
  "$DFLASH_ROOT/runtime_patch_tp4/sitecustomize.py" \
  "$SITE/sglang/srt/models/dflash.py" \
  "$SITE/sglang/srt/speculative/dflash_worker.py" \
  "$SITE/sglang/srt/speculative/dflash_utils.py"

echo "Installed Qwen3.8 K100AI profiles: TP1 / TP2 / TP4"
