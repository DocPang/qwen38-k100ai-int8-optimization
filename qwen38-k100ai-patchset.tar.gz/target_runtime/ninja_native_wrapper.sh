#!/bin/sh
exec /usr/bin/ninja "$@"
